<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Hasil Quisioner</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Hasil</li>
              <li class="breadcrumb-item active" aria-current="page">Hasil Quisioner</li>
            </ol>
          </div>

          <!-- Row -->
          <div class="row">
            <!-- DataTable with Hover -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="table-responsive p-3">
                <form action="index.php?page=data_dosen_multidelete" method="POST">
                
<P></P>
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>No</th>
                        <th>Kode PT</th>
                        <th>Tahun Lulus</th>
                        <th>Kode Prodi</th>
                        <th>Nama </th>
                        <th>Nomor Telpon</th>
                        <th>Email</th>
                        <th>NIK</th>
                        <th>NPWP</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                  
                    </tfoot>
                    <tbody>
                     <?php
        include"../koneksi.php";
        $sqlu = mysqli_query($con,"SELECT * FROM hasil");
        $no=1;
        while($ru = mysqli_fetch_array($sqlu)){ $hasil = json_decode($ru['hasil']);
        ?>
            <tr>
                <td><?php echo"$no"; ?></td>
                <td><?php echo"$ru[kode_pt]"; ?></td>
                <td><?php echo"$ru[tahun_lulus]"; ?></td>
                <td><?php echo"$ru[prodi]"; ?></td>
                <td><?php echo"$ru[nama]"; ?></td>
                <td><?php echo"$ru[notelp]"; ?></td>
                <td><?php echo"$ru[email]"; ?></td>
                <td><?php echo"$ru[nik]"; ?></td>
                <td><?php echo"$ru[npwp]"; ?></td>
                <td><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?=$no?>"><i class='fas fa-eye'></i></button>
                    
                </td>

            </tr>

            <!-- Modal -->
  <div class="modal fade" id="myModal<?=$no?>" role="dialog">
    <div class="modal-dialog modal-xl">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Show</h4>
        </div>
        <div class="modal-body container">
            <div class="row">
                <div class='col-6'>
                    <h3>Pertanyaan</h3>
                </div>
                <div class='col-1'>
                </div>
                <div class='col-5'>
                    <h3>Jawaban</h3>
                </div>
            </div>
            <hr>
            <?php foreach($hasil as $h){?>
            <div class="row">
                <div class='col-6'>
                    <?=$h->pertanyaan?>
                </div>
                <div class='col-1'>
                    :
                </div>
                <div class='col-5'>
                    <?=$h->jawaban?>
                </div>
            </div>
            <br>
            <?php }?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
        <?php
        $no++;
        }
        ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>