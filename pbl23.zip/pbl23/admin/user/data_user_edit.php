<?php
include "../koneksi.php";

$sqlal = mysqli_query($con, "SELECT * FROM user WHERE id_user = $_GET[id]");
$ral = mysqli_fetch_array($sqlal);

?>

<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Form Edit Data User</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">User's</li>
              <li class="breadcrumb-item">Data User</li>
              <li class="breadcrumb-item active" aria-current="page">Form Edit Data User</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
             
              <div class="card mb-4">
              
                <div class="card-body">
                  <form action="#" method="post">

                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Username</b></label>
                      <input type="hidden" class="form-control" name="id_user" value="<?php echo"$ral[id_user]"; ?>">
                      
                      <input type="text" class="form-control" name="username" placeholder="Masukkan Username"  value="<?php echo"$ral[username]"; ?>">
                    </div>
                   </div>

                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Password</b></label>
                      <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                    </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Nama</b></label>
                      <input type="" class="form-control" name="nm_user" placeholder="Masukkan Nama"  value="<?php echo"$ral[nm_user]"; ?>">
                   </div>
                   </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Status</b></label>
                      <input type="" class="form-control" name="status" placeholder="Masukkan Status"  value="<?php echo"$ral[status]"; ?>">
                    </div>
                    </div>

                                     
                 </div>

                  </div>
                     <br>
                    <div class="form-actions">
                    <div class="text-right">
                      <input type="submit" name="submit" class="btn btn-success" value="Simpan Data">
                      <button type="reset" class="btn btn-dark">Reset</button>
                    </div>
                    </div>

                  </form>
                </div>
              </div>
              </div>



<?php 
if($_SERVER['REQUEST_METHOD']== "POST"){
    include"../koneksi.php";

    $query = mysqli_query($con,"UPDATE user SET username='$_POST[username]', password='$_POST[password]', nm_user='$_POST[nm_user]',status='$_POST[status]'  where id_user='$_POST[id_user]'");

    echo"<script language = 'JavaScript'>
         confirm('Data Berhasil Diubah!');
         document.location='index.php?page=data_user'
    </script>";
}
?>