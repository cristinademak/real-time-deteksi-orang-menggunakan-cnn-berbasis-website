<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data User</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">User</li>
              <li class="breadcrumb-item active" aria-current="page">Data User</li>
            </ol>
          </div>

          <!-- Row -->
          <div class="row">
            <!-- DataTable with Hover -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="table-responsive p-3">
                <form action="index.php?page=data_dosen_multidelete" method="POST">
                <a href="index.php?page=data_user_input" class="btn btn-primary">Tambah Data</a>
                <input type="submit" name="tombol_delete" class='btn btn-danger' onclick=" javascript: return confirm('Apakah Anda Yakin Menghapus Data ini ?')" value="Delete Data">
<P></P>
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th></th>
                        <th>No</th>
                        <th>Nama User</th>
                        <th>Username</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php
        include"../koneksi.php";
        $sqlu = mysqli_query($con,"SELECT * FROM user");
        $no=1;
        while($ru = mysqli_fetch_array($sqlu)){
        ?>
            <tr>
                <td><input type="checkbox" name="id_user[]" value="<?php echo"$ru[id_user]"; ?>"></td>
                <td><?php echo"$no"; ?></td>
                <td><?php echo"$ru[nm_user]"; ?></td>
                <td><?php echo"$ru[username]"; ?></td>
                <td><?php echo"$ru[status]"; ?></td>
                <td><?php echo"<a href='index.php?page=data_user_edit&id=$ru[id_user]' class='btn btn-warning'>Edit</a>"; ?>
                    <a <?php echo" href='index.php?page=data_user_delete&id=$ru[id_user]'"; ?> class='btn btn-danger' onclick="return confirm('Apakah Anda Yakin Menghapus Data ini ?')">Delete</a>
                </td>

            </tr>
        <?php
        $no++;
        }
        ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>