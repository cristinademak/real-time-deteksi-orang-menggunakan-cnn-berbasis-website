

<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Form Input Data User</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">User's</li>
              <li class="breadcrumb-item">Data User</li>
              <li class="breadcrumb-item active" aria-current="page">Form Input Data User</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
             
              <div class="card mb-4">
              
                <div class="card-body">
                  <form action="#" method="post">

                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Username</b></label>
                      <input type="text" class="form-control" name="username" placeholder="Masukkan Username" >
                    </div>
                   </div>

                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Password</b></label>
                      <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                    </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Nama</b></label>
                      <input type="" class="form-control" name="nm_user" placeholder="Masukkan Nama">
                   </div>
                   </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Status</b></label>
                      <input type="" class="form-control" name="status" placeholder="Masukkan Status">
                    </div>
                    </div>

                                     
                 </div>

                  </div>
                     <br>
                    <div class="form-actions">
                    <div class="text-right">
                      <input type="submit" name="submit" class="btn btn-success" value="Simpan Data">
                      <button type="reset" class="btn btn-dark">Reset</button>
                    </div>
                    </div>

                  </form>
                </div>
              </div>
              </div>



<?php 
if($_SERVER['REQUEST_METHOD']== "POST"){
    include"../koneksi.php";

    $query = mysqli_query($con,"INSERT INTO user (username,password,nm_user,status) values ('$_POST[username]','$_POST[password]','$_POST[nm_user]','$_POST[status]')");

    echo"<script language = 'JavaScript'>
         confirm('Data Berhasil Disimpan!');
         document.location='index.php?page=data_user'
    </script>";
}
?>