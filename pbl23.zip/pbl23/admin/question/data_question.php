<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Question FTI</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Question's</li>
              <li class="breadcrumb-item active" aria-current="page">Data Question FTI</li>
            </ol>
          </div>

          <!-- Row -->
          <div class="row">
            <!-- DataTable with Hover -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="table-responsive p-3">
                <form action="index.php?page=data_dosen_multidelete" method="POST">
                <a href="index.php?page=data_question_input" class="btn btn-outline-primary">Tambah Data</a>
                <a href="alumni/cetak_data_question.php" target="_blank" class="btn btn-outline-success">Cetak Data</a>
                <input type="submit" name="tombol_delete" class='btn btn-outline-danger' onclick=" javascript: return confirm('Apakah Anda Yakin Menghapus Data ini ?')" value="Delete Data">
                
<P></P>
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th></th>
                        <th><center>No</th>
                        <th><center>Pertanyaan</th>
                        <th><center>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th></th>
                        <th><center>No</th>
                        <th><center>Pertanyaan</th>
                        <th><center>Action</th>
                      </tr>
                    </tfoot>
                    <tbody>
        <?php
        include"../koneksi.php";
        $sqlp = mysqli_query($con,"SELECT * FROM quisioner");
        $no=1;
        while($rp = mysqli_fetch_array($sqlp)){
        ?>
            <tr>
              <td><center><input type="checkbox" name="id_question[]" value="<?php echo"$rp[id_question]"; ?>"></td>
              <td><center><?php echo"$no"; ?></td>
              <td><center><?php echo"$rp[pertanyaan]"; ?></td>       
              <td><center>
            <?php echo "<a href='index.php?page=data_question_edit&id=$rp[id_question]' class='btn btn-success'><i class='fas fa-edit'></i></a>"; ?>
            <a <?php echo " href='index.php?page=data_question_delete&id=$rp[id_question]'"; ?> class='btn btn-danger' onclick="return confirm('Apakah Anda Yakin Menghapus Data ini ?')"><i class='fas fa-trash-alt'></i></a></td>

            </tr>
        <?php
        $no++;
        }
        ?>
                   </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>