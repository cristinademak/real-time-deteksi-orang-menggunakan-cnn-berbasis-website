<?php
include "../koneksi.php";

$sqlp = mysqli_query($con, "SELECT * FROM prodi WHERE id_prodi = $_GET[id]");
$rp = mysqli_fetch_array($sqlp);

?>

<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Prodi FTI</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Prodi's</li>
              <li class="breadcrumb-item active" aria-current="page">Data Prodi FTI</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
             
              <div class="card mb-4">
              
                <div class="card-body">
                  <form action="#" method="post">

                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Kode Prodi</b></label>
                      <input type="hidden" class="form-control" name="id_prodi" value="<?php echo"$rp[id_prodi]" ?>">
                      <input type="text" readonly="readonly" class="form-control" name="kd_prodi" value="<?php echo"$rp[kd_prodi]" ?>">
                    </div>
                   </div>


                  <div class="col-md-6">
                    <div class="form-group">
                      <label><b>Nama Prodi</b></label>
                      <input type="text" readonly="readonly" class="form-control" name="nm_prodi" value="<?php echo"$rp[nm_prodi]" ?>">
                    </div>
                   </div>

                    </div>
                    </div>
                </div>
              </div>
           </div>

<div class="row">
            <!-- DataTable with Hover -->
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="table-responsive p-3">
                

                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>No</th>
                        <th>Nim</th>
                        <th>Nama</th>
                        <th>Angkatan</th>
                        <th>Jenis Kelamin</th>
                      </tr>
                    </thead>
                    
                    
                    
 <tbody>
        <?php
        include"../koneksi.php";

        $sqlpro = mysqli_query($con, "SELECT * FROM prodi_alumni WHERE id_prodi = $rp[id_prodi]");
        $no = 1;
        while ( $rpro = mysqli_fetch_array($sqlpro)){
        $sqlal = mysqli_query($con,"SELECT * FROM alumni WHERE id_alumni = $rpro[id_alumni]");
        $ral = mysqli_fetch_array($sqlal);
        ?>
            <tr>
              <td><?php echo"$no"; ?></td>
              <td><?php echo"$ral[nim_alumni]"; ?></td>
              <td><?php echo"$ral[nm_alumni]"; ?></td>
              <td><?php echo"$ral[angkatan]"; ?></td>
              <td><?php echo"$ral[gender]"; ?></td>
            </tr>
        <?php
        $no++;
        }
        ?>
                   </tbody>


                </table>
            </div>
        </div>






