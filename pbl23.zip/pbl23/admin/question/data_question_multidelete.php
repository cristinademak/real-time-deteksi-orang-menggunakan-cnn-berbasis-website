<?php
include"../koneksi.php";
    if(isset($_POST["id_prodi"])){
    	foreach($_POST["id_prodi"] as $id) {
    		$query = "DELETE from prodi where id_prodi=?";
    		$del = $con->prepare($query);
    		$del->bind_param("i", $id);
    		$del->execute();

    	}   	
    }
    echo "<script language = 'JavaScript'>
      confirm('Data Berhasil Dihapus!');
      document.location='index.php?page=data_prodi';
      </script>";
?>