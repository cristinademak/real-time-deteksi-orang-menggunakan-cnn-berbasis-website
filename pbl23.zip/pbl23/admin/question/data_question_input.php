<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Form Input Data Quisioner</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Quisioner's</li>
              <li class="breadcrumb-item">Data Quisioner</li>
              <li class="breadcrumb-item active" aria-current="page">Form Input Data Quiosioner</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
             
              <div class="card mb-4">
              
                <div class="card-body">
                  <form action="#" method="post">
                    <div class="form-group">
                      <label><b>Pertanyaan</b></label>
                      <textarea class="form-control" name="pertanyaan" placeholder="Masukkan Pertanyaan"></textarea>
                    </div>

                  </form>   
                </div>
                </div>
              </div>
</div>


<?php 
if($_SERVER['REQUEST_METHOD']== "POST"){
    include"../koneksi.php";

    $query = mysqli_query($con,"INSERT INTO quisioner (pertanyaan) values ('$_POST[pertanyaan]')");

    echo"<script language = 'JavaScript'>
         confirm('Data Berhasil Disimpan!');
         document.location='index.php?page=quisioner'
    </script>";
}
?>