<?php
include "../koneksi.php";

$sqlp = mysqli_query($con, "SELECT * FROM quisioner WHERE id_question = $_GET[id]");
$rp = mysqli_fetch_array($sqlp);

?>
<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Form Edit Data Prodi</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Prodi's</li>
              <li class="breadcrumb-item">Data Prodi</li>
              <li class="breadcrumb-item active" aria-current="page">Form Edit Data Prodi</li>
            </ol>
          </div>

          <div class="row">
            <div class="col-lg-12">
             
              <div class="card mb-4">
              
                
              <div class="card-body">
                  <form action="#" method="post">
                    <div class="form-group">
                      <label><b>Pertanyaan</b></label>
                      <input type="hidden" class="form-control" name="id_question" value="<?php echo"$rp[id_question]"; ?>">
                      <textarea class="form-control" name="pertanyaan" placeholder="Masukkan Pertanyaan"><?=$rp['pertanyaan']?></textarea>
                    </div>
                     <br>
                    <div class="form-actions">
                    <div class="text-right">
                      <input type="submit" name="submit" class="btn btn-success" value="Simpan Data">
                      <button type="reset" class="btn btn-dark">Reset</button>
                    </div>
                    </div>

                  </form>   
                </div>
                </div>
              </div>
                </div>
              </div>
</div>


<?php 
if($_SERVER['REQUEST_METHOD']== "POST"){
    include"../koneksi.php";

    $query = mysqli_query($con,"UPDATE quisioner SET pertanyaan='$_POST[pertanyaan]'  where id_question='$_POST[id_question]'");

    echo"<script language = 'JavaScript'>
         confirm('Data Berhasil Disimpan!');
         document.location='index.php?page=quisioner'
    </script>";
}
?>